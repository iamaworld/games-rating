const { getData } = require("./ali-utils");
const endpoints = require("./config");
const { getRandomGame } = require("./ali-utils");

module.exports = {
  getData,
  endpoints,
  getRandomGame,
};
